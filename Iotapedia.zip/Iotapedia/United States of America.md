*Translations*

- Spanish: [[Estados Unidos de América]]
- French: [[États-Unis d’Amérique]]
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[European colonial expansion]], 1492–1763
2. [[USA revolution]], 1763–1789
3. [[USA westward expansion]], 1789–1861
4. [[USA civil war]], 1861–1865
5. [[USA reconstruction era]], 1865–1877
6. [[USA gilded age]], 1877–c. 1900
7. [[USA progressive era]], c. 1900–1920
8. [[USA roaring twenties]], 1920–1929
9. [[Great Depression]], 1929–1939
10. [[World War II]], 1939–1945
11. [[USA hegemony]],  1945–

#america #usa 
