*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Modern Middle East*

- [[Saudi Arabia]]
- [[Yemen]]
- [[Afghanistan]]
- [[Iraq]]
- [[Iran]]

#eurasia #asia #mideast