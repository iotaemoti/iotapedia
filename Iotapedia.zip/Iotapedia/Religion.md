*Translations*

- Spanish: [[Religión]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*One God, many gods, no gods*

1. [[Monotheism]]
2. [[Polytheism]]
3. [[Atheism]]
4. [[Agnosticism]]

#religion #god 