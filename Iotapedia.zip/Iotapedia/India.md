*Translations*

- Spanish: [[India (español)]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Republic of India]], 1947–

---

*Bibliography*

#eurasia #asia #india 