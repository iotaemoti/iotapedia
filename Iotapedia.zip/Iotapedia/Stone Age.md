*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Paleolithic]], c. 3.3 millions years ago–c. 10,000 years ago
2. [[Mesolithic]]
3. [[Neolithic]]

#prehistory #stoneage 