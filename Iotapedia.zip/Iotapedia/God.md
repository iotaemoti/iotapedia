*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Bibliography*

Armstrong, Karen, *A History of God: The 4,000-Year Quest of Judaism, Christianity and Islam* (1994)

#god 