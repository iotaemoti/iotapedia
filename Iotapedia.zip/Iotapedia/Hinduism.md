*Translations*

- Spanish: [[Hinduismo]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Bibliography*

Flood, Gavin, *An Introduction to Hinduism* (1996)

#eurasia #asia #india #religion #hindu