*Translations*

- Spanish: [[Monoteísmo]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Abrahamic religions*

1. [[Judaism]]
2. [[Christianity]]
3. [[Islam]]

#religion #god 