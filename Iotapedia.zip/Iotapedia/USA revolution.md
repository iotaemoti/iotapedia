*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. Second Continental Congress uses the name “United Colonies,” 1775
2. Declaration of Independence uses the phrase “the thirteen united States of America,” 1776
3. Congress uses the name “United States of America,” 1776
4. Flag of the United States, 1777
5. Continental Congress adopts the Great Seal of the United States, 1782

#america #usa #revolution