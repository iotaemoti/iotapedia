*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

#religion #islam 