*Bibliography*

Greene, Robert, *The 48 Laws of Power* (1998)
—, *The Art of Seduction* (2001)
—, *The 33 Strategies of War* (2006)
—, *The 50th Law* (2009)
—, *Mastery* (2012)
—, *The Laws of Human Nature* (2018)

#pow