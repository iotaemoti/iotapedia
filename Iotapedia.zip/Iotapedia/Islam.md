*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

#religion #god #islam 