*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Contents*

1. [[Big bang]]
2. [[Prehistory]]