*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. Earliest known [[solar calendar]], c. 3000 BCE

#prehistory #bronzeage