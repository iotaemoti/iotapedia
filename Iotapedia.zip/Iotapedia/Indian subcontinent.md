*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Modern Indian subcontinent*

- [[Republic of India]]

#eurasia #asia 