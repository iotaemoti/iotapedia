*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Modern Afro-Eurasia*

- [[Africa]]
- [[Eurasia]]

#africa #eurasia