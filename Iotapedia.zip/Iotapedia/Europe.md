*Translations*

- Spanish: [[Europa]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Medieval era]], c. 401–c. 1492
2. [[European colonial expansion]], 1492–1763

---

*Modern Europe*

- [[Germany]]

#eurasia #eu 