*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. Introduced by [[Julius Caesar]], 46 BCE

#sci #astro 