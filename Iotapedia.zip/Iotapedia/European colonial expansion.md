*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Renaissance]], c. 1492–c. 1700

#eurasia #eu 