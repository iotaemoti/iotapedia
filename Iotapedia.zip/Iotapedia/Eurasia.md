*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Modern Eurasia*

- [[Asia]]
- [[Europe]]

#eurasia #asia #eu 