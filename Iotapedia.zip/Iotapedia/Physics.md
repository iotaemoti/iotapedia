*Translations*

- Spanish: [[Física]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Topics*

- [[Astrophysics]]
- [[Electromagnetism]]
- [[Fluid mechanics]]
- [[Mechanics]]
- [[Optics]]
- [[Particle physics]]
- [[Quantum mechanics]]
- [[States of matter]]
- [[String theory]]
- [[Thermodynamics]]
- [[Wave motion]]

#sci #phys 