*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Bibliography*

Kissinger, Henry, *Leadership: Six Studies in World Strategy* (2022)