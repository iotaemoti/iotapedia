*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. Believing Youth founded by [[Hussein Badreddin al-Houthi]], 1992
2. Yemeni security forces kill Hussein Badreddin al-Houthi, 2004

#eurasia #asia #mideast #yemen #religion #islam 