*Translations*

- Spanish: [[Cristianismo]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

#religion #god #christ 