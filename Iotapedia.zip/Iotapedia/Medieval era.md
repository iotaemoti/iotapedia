*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Hildegard von Bingen]] born on September 16, 1098

---

*Last time*

...

*This time*

c. 401–c.1500

*Next time*

#eurasia #eu #medieval  