*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Hildegard von Bingen]] born on September 16, 1098

#eurasia #eu #deutsch 