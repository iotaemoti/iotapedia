*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*Modern South Asia*

- [[Indian subcontinent]]

#eurasia #asia 