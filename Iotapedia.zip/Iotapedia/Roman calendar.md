*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Julian calendar]] introduced by [[Julius Caesar]], 46 BCE

#sci #astro 