*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Lower Paleolithic]], c. 3.3 million years ago–c. 300,000 years ago
2. [[Middle Paleolithic]], c. 300,000 years ago–c. 50,000 years ago
3. [[Upper Paleolithic]], c. 50,000 years ago–c. 10,000 years ago

#prehistory #stoneage #paleolithic