*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. Born on July 28, 1902
2. *The Logic of Scientific Discovery* published, 1934
3. Fled Nazi persecution, 1937
4. *The Open Society and Its Enemies* published, 1945

#eurasia #eu #austria #phil #sci 