*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. Born on September 16, 1098
2. Took monastic vows, c. 1113
3. Elected magistra of the women’s community, 1136
4. Founded her own monastery, 1150
5. Died on September 17, 1179
6. Canonized, 2012

---

A Doctor of the Church.

#medieval #religion #sci #med #music 