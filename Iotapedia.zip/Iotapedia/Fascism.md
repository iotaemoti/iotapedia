*Translations*

- Spanish:
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. First “Futurist Manifesto” by Filippo Tomaso Marinetti published, 1909
2. Fascism born on March 23, 1919

#fascism 