*Translations*

- Spanish: [[Europa]]
- French:
- German:
- Russian:
- Arabic:
- Chinese:

---

*A brief history*

1. [[Medieval era]], c. 401–c. 1500

---

*Modern Europe*

- [[Germany]]

#eurasia #eu 